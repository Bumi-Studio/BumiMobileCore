namespace BumiMobile
{
    public interface IPopupWindow 
    {
        bool IsOpened { get; }
    }
}
